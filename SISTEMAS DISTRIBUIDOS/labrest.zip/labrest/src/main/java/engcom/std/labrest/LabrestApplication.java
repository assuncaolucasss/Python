package engcom.std.labrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabrestApplication.class, args);
	}

}
